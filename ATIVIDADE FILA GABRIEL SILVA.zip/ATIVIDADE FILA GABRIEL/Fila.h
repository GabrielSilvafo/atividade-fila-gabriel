#ifndef FILA_H_INCLUDED
#define FILA_H_INCLUDED

// Tipo de dado que sera armazenado na fila (neste caso, inteiros)
typedef int TipoDado;

// Definicao da celula da fila, contendo o dado e o ponteiro para o proximo
struct TipoCelula {
    TipoDado Item;  // Dado armazenado
    TipoCelula *Prox;  // Ponteiro para a proxima celula
};

// Declaracao das funcoes da fila

void Fila_Construtor();      // Inicializa a fila
void Fila_Destrutor();       // Libera a memoria da fila
bool Fila_Vazia();           // Verifica se a fila esta vazia
int Fila_Tamanho();          // Retorna o tamanho da fila
bool Fila_Enfileirar(TipoDado Elemento);  // Insere um elemento na fila
bool Fila_Desenfileirar(TipoDado &Elemento);  // Remove um elemento da fila
bool Fila_Frente(TipoDado &Elemento);  // Retorna o primeiro elemento sem remove-lo

#endif // FILA_H_INCLUDED
