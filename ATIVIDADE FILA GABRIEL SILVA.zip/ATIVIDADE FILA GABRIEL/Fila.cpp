#include "Fila.h"
#include <cstdlib>  // Biblioteca para uso de funcoes como malloc e free

// Estrutura global que guarda a cabeca e o final da fila
struct TipoFila {
    TipoCelula *Inicio;  // Ponteiro para o primeiro elemento
    TipoCelula *Fim;     // Ponteiro para o ultimo elemento
    int Tamanho;         // Numero de elementos na fila
} Fila;

// Funcao que inicializa a fila
void Fila_Construtor() {
    Fila.Inicio = nullptr;  // Inicio e fim da fila apontam para nullptr
    Fila.Fim = nullptr;
    Fila.Tamanho = 0;       // Inicialmente a fila tem tamanho zero
}

// Funcao que destroi a fila e libera a memoria
void Fila_Destrutor() {
    TipoCelula *Temp;
    while (Fila.Inicio != nullptr) {
        Temp = Fila.Inicio;
        Fila.Inicio = Fila.Inicio->Prox;
        free(Temp);  // Libera a memoria da celula
    }
    Fila.Fim = nullptr;
    Fila.Tamanho = 0;
}

// Verifica se a fila esta vazia
bool Fila_Vazia() {
    return (Fila.Inicio == nullptr);
}

// Retorna o numero de elementos na fila
int Fila_Tamanho() {
    return Fila.Tamanho;
}

// Funcao para enfileirar um elemento na fila
bool Fila_Enfileirar(TipoDado Elemento) {
    TipoCelula *NovaCelula = (TipoCelula *)malloc(sizeof(TipoCelula));
    if (NovaCelula == nullptr) return false;  // Falha na alocacao de memoria

    NovaCelula->Item = Elemento;
    NovaCelula->Prox = nullptr;

    if (Fila.Fim != nullptr) Fila.Fim->Prox = NovaCelula;
    else Fila.Inicio = NovaCelula;

    Fila.Fim = NovaCelula;
    Fila.Tamanho++;
    return true;
}

// Funcao para desenfileirar um elemento
bool Fila_Desenfileirar(TipoDado &Elemento) {
    if (Fila_Vazia()) return false;

    TipoCelula *Temp = Fila.Inicio;
    Elemento = Temp->Item;
    Fila.Inicio = Fila.Inicio->Prox;

    if (Fila.Inicio == nullptr) Fila.Fim = nullptr;
    free(Temp);
    Fila.Tamanho--;
    return true;
}

// Funcao que retorna o primeiro elemento sem remover
bool Fila_Frente(TipoDado &Elemento) {
    if (Fila_Vazia()) return false;
    Elemento = Fila.Inicio->Item;
    return true;
}
