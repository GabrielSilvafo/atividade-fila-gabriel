//Atividade - Filas
//Armazenar em uma fila uma sequencia aleatoria e com quantidade indefinida de matriculas e notas que os alunos tiraram em uma prova.
//Os dados devem ser fornecidos pelo usuario e armazenados em uma fila na mesma ordem em que foram digitados.
//Sempre que o usuario fornece uma matricula deve fornecer tambem a respectiva nota do aluno. Os dados devem entao serem armazenados em uma
//pilha de forma que fiquem ordenados e que a maior nota fique no topo. Em caso de empate entre duas notas a matricula pode ser utilizada
//como criterio de desempate, uma vez que nao ha matriculas repetidas. Ao final do processo, desempilhar os elementos e apresenta-los na tela.
//Como tratam-se de dados com uma quantidade indefinida, nao se deve utilizar um vetor para fazer a ordenacao dos dados.

#include <cstdio>    // Biblioteca para funcoes de entrada e saida de dados
#include <cstdlib>   // Biblioteca para alocacao dinamica de memoria
#include "Fila.h"    // Cabecalho com as definicoes da fila

using namespace std; // Uso de funcoes da biblioteca padrao

// Exibe o menu e permite a interacao do usuario com a fila
int main() {
    int valor;  // Variavel para armazenar valores inseridos pelo usuario
    int escolha;  // Variavel para controlar o menu de opcoes

    // Inicializacao da fila antes do uso
    Fila_Construtor();

    // Mensagem inicial ao usuario
    printf("Digite inteiros para enfileirar na fila\n");

    // Fazer com que o menu sempre volte
    do {
        system("cls"); // Limpa a tela

        // Exibicao do menu de opcoes
        printf("Gerenciamento Dinamico de Filas - Sistema Interativo\n\n");
        printf("Para continuar escolha uma opcao:\n");
        printf("\nOpcao 1 - Inserir elemento (Enfileirar)");
        printf("\nOpcao 2 - Remover elemento (Desenfileirar)");
        printf("\nOpcao 3 - Ver primeiro elemento");
        printf("\nOpcao 4 - Tamanho da fila");
        printf("\nOpcao 5 - Verificar se a fila esta vazia");
        printf("\nOpcao 6 - Sair do programa\n");
        printf("\nescolha: ");
        scanf("%d", &escolha);  // Le a opcao do usuario

        // Executa a acao escolhida pelo usuario
        switch(escolha) {
            case 1:
                // Enfileira um elemento
                printf("\nDigite o valor: ");
                scanf("%d", &valor);
                if(Fila_Enfileirar(valor))
                    printf("\nElemento inserido com sucesso\n");
                else
                    printf("\nErro: Falha na alocacao de memoria\n");
                system("pause");
                break;

            case 2:
                // Remove um elemento da fila
                if(Fila_Desenfileirar(valor))
                    printf("\nElemento removido com sucesso: %d\n", valor);
                else
                    printf("\nFila vazia, infelizmente nao foi possivel remover o elemento\n");
                system("pause");
                break;

            case 3:
                // Exibe o primeiro elemento
                if(Fila_Frente(valor))
                    printf("\nPrimeiro elemento: %d\n", valor);
                else
                    printf("\nA fila esta vazia\n");
                system("pause");
                break;

            case 4:
                // Exibe o numero de elementos na fila
                printf("\nNumero de elementos na fila: %d\n", Fila_Tamanho());
                system("pause");
                break;

            case 5:
                // Verifica se a fila esta vazia
                if(Fila_Vazia())
                    printf("\nA fila esta vazia\n");
                else
                    printf("\nA fila contem elementos\n");
                system("pause");
                break;

            case 6:
                // Finaliza o programa
                Fila_Destrutor();
                printf("\nSaindo...\n");
                system("pause");
                break;

            default:
                // Caso a opcao seja invalida
                printf("\nOpcao invalida, tente novamente\n");
                system("pause");
                break;
        }
    } while(escolha != 6);

    return 0;  // Finaliza o programa
}
